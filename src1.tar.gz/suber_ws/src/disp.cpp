﻿/*
* 语音合成（Text To Speech，TTS）技术能够自动将任意文字实时转换为连续的
* 自然语音，是一种能够在任何时间、任何地点，向任何人提供语音信息服务的
* 高效便捷手段，非常符合信息时代海量数据、动态更新和个性化查询的需求。
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Int16.h>//1-1
#include "qtts.h"
#include "msp_cmn.h"
#include "msp_errors.h"

const char* fileName="/home/neu/catkin_ws/voices.wav";//1-2
const char* playPath="play /home/neu/catkin_ws/voices.wav";//1-3
/* wav音频头部格式 */
typedef struct _wave_pcm_hdr
{
	char            riff[4];                // = "RIFF"头文件格式
	int		size_8;                 // = FileSize - 8
	char            wave[4];                // = "WAVE"
	char            fmt[4];                 // = "fmt "
	int		fmt_size;		// = 下一个结构体的大小 : 16，表示设置参数的字节数量为16，跳过这16个字节的内容

	short int       format_tag;             // = PCM : 1
	short int       channels;               // = 通道数 : 1
	int		samples_per_sec;        // = 采样率 : 8000 | 6000 | 11025 | 16000
	int		avg_bytes_per_sec;      // = 每秒字节数 : samples_per_sec * bits_per_sample / 8
	short int       block_align;            // = 每采样点字节数 : wBitsPerSample / 8
	short int       bits_per_sample;        // = 量化比特数: 8 | 16

	char            data[4];                // = "data";
	int		data_size;              // = 纯数据长度 : FileSize - 44 
} wave_pcm_hdr;

/* 默认wav音频头部数据 */
wave_pcm_hdr default_wav_hdr = 
{
	{ 'R', 'I', 'F', 'F' },//4个char填充4个字节
	0,//文件总字节数，暂且默认为0，音频文件加上文件头从“wave”开始的大小
	{'W', 'A', 'V', 'E'},//文件标志
	{'f', 'm', 't', ' '},//波形格式标志
	16,//过滤字节，不计算这部分内容，直接跳到文件内容
	1,
	1,//单双声道
	16000,//采样频率
	32000,//每秒字节数
	2,//data数据块字节
	16,//pcm位宽2*8
	{'d', 'a', 't', 'a'},
	0  //语音文件，不包括文件头
};
/* 文本合成 */
int text_to_speech(const char* src_text, const char* des_path, const char* params)//文本，语音材料，发音参数
{
	int          ret          = -1;
	FILE*        fp           = NULL;
	const char*  sessionID    = NULL;
	unsigned int audio_len    = 0;
	wave_pcm_hdr wav_hdr      = default_wav_hdr;
	int          synth_status = MSP_TTS_FLAG_STILL_HAVE_DATA;

	if (NULL == src_text || NULL == des_path)
	{
		printf("params is error!\n");
		return ret;
	}
	fp = fopen(des_path, "wb");
	if (NULL == fp)
	{
		printf("open %s error.\n", des_path);
		return ret;
	}
	/* 开始合成 */
	sessionID = QTTSSessionBegin(params, &ret);//开始合成输入参数
	if (MSP_SUCCESS != ret)
	{
		printf("QTTSSessionBegin failed, error code: %d.\n", ret);
		fclose(fp);
		return ret;
	}
	ret = QTTSTextPut(sessionID, src_text, (unsigned int)strlen(src_text), NULL);//根据回话ID
	if (MSP_SUCCESS != ret)
	{
		printf("QTTSTextPut failed, error code: %d.\n",ret);
		QTTSSessionEnd(sessionID, "TextPutError");
		fclose(fp);
		return ret;
	}
	printf("正在合成 ...\n");
	fwrite(&wav_hdr, sizeof(wav_hdr) ,1, fp); //添加wav音频头，使用采样率为16000，写入的头指针，文件尺寸，次数，写入到哪个文件里面，共写入44个字节
	while (1) 
	{
		/* 获取合成音频 */
		const void* data = QTTSAudioGet(sessionID, &audio_len, &synth_status, &ret);//根据sessionID返回
		if (MSP_SUCCESS != ret)
			break;
		if (NULL != data)
		{
			fwrite(data, audio_len, 1, fp);//写入头指针，返回音频文件字节，1次，文件
		    wav_hdr.data_size += audio_len; //计算data_size大小，纯数据长度
		}
		if (MSP_TTS_FLAG_DATA_END == synth_status)
			break;
		printf(">");
		usleep(15*1000); //防止频繁占用CPU
	}
	printf("\n");
	if (MSP_SUCCESS != ret)
	{
		printf("QTTSAudioGet failed, error code: %d.\n",ret);
		QTTSSessionEnd(sessionID, "AudioGetError");
		fclose(fp);
		return ret;
	}
	/* 修正wav文件头数据的大小 */
	wav_hdr.size_8 += wav_hdr.data_size + (sizeof(wav_hdr) - 8);
	
	/* 将修正过的数据写回文件头部,音频文件为wav格式 */
	fseek(fp, 4, 0);//从0开始正向偏移4个字节
	fwrite(&wav_hdr.size_8,sizeof(wav_hdr.size_8), 1, fp); //写入size_8的值
	fseek(fp, 40, 0); //将文件指针偏移到存储data_size值的位置，
	fwrite(&wav_hdr.data_size,sizeof(wav_hdr.data_size), 1, fp); //写入data_size的值
	fclose(fp);
	fp = NULL;
	/* 合成完毕 */
	ret = QTTSSessionEnd(sessionID, "Normal");
	if (MSP_SUCCESS != ret)
	{
		printf("QTTSSessionEnd failed, error code: %d.\n",ret);
	}

	return ret;
}
//make topic callback text to wav file
int makeTextToWav(const char* text,const char* filename)
{
	int         ret                  = MSP_SUCCESS;
	const char* login_params         = "appid = 5a95221e, work_dir = .";//登录参数,appid与msc库绑定,请勿随意改动
	/*
	* rdn:           合成音频数字发音方式

	* volume:        合成音频的音量
	* pitch:         合成音频的音调
	* speed:         合成音频对应的语速

	* voice_name:    合成发音人
	* sample_rate:   合成音频采样率

	* text_encoding: 合成文本编码格式
	*

	*/
	const char* session_begin_params = "voice_name = xiaowanzi, text_encoding = utf8, sample_rate = 16000, speed = 50, volume = 50, pitch = 50, rdn = 0";
	//const char* filename             = "tts_sample.wav"; //合成的语音文件名称
	//const char* text                 = "大家好，我是东北大学TDT创新团队的天宝。"; //合成文本

	/* 用户登录 */
	ret = MSPLogin(NULL, NULL, login_params);//第一个参数是用户名，第二个参数是密码，第三个参数是登录参数，用户名和密码可在http://www.xfyun.cn注册获取
	if (MSP_SUCCESS != ret)
	{
		printf("MSPLogin failed, error code: %d.\n", ret);
		goto exit ;//登录失败，退出登录
	}
	printf("\n###########################################################################\n");
	printf("## 语音合成（Text To Speech，TTS）技术能够自动将任意文字实时转换为连续的 ##\n");
	printf("## 自然语音，是一种能够在任何时间、任何地点，向任何人提供语音信息服务的  ##\n");
	printf("## 高效便捷手段，非常符合信息时代海量数据、动态更新和个性化查询的需求。  ##\n");
	printf("###########################################################################\n\n");
	/* 文本合成 */
	printf("开始合成 ...\n");
	ret = text_to_speech(text, filename, session_begin_params);//语音播放字符串
	if (MSP_SUCCESS != ret)
	{
		printf("text_to_speech failed, error code: %d.\n", ret);
	}
	printf("合成完毕\n");

exit:
	//printf("按任意键退出 ...\n");
	//getchar();
	MSPLogout(); //退出登录
	return 0;

}
//play compose wav file 自动调用音频
void playWav()
{
	system(playPath);
}
//topic auto invoke,make text to wav file,then play file
void topicCallBack(const std_msgs::Int16::ConstPtr& msg)
{
	 ROS_INFO("I heard:[%d]",msg->data);
	switch (msg->data)//1-5
{
	case 1:
{
	const char *addd="我是东北大学TDT创新团队的天宝机器人，看我很可爱吧。我可以模仿你的动作哦！在未来我是你的家庭小帮手，也是你的好伙伴。我能够帮助照顾老人，提供行动上的辅助和情感上的交流。";
	std::cout<<"get topic text:"<<addd;
	makeTextToWav(addd,fileName);
	playWav();
	break;
}
	case 2:
{
	const char *addd="该我上场表演了!一篇诗，一斗酒，一曲长歌，一剑天涯。但愿长醉不复醒!";
	std::cout<<"get topic text:"<<addd;
	makeTextToWav(addd,fileName);
	playWav();
	break;
}
case 3:
{
	const char *addd="有朋自远方来，不亦乐乎。拥有了青春，也就拥抱了永恒,知识，就是力量!";
	std::cout<<"get topic text:"<<addd;
	makeTextToWav(addd,fileName);
	playWav();
	break;
}
case 4:
{
	const char *addd="时间和波浪，变化无常。我思故我在!";
	std::cout<<"get topic text:"<<addd;
	makeTextToWav(addd,fileName);
	playWav();
	break;
}

default:
{
 	const char *addd="世界不止眼前的苟且，还有诗和远方!世界那么大，我想来看看。";
	std::cout<<"get topic text:"<<addd;
	makeTextToWav(addd,fileName);
	playWav();
	break;
}
}
}

int main(int argc, char* argv[])  
{
	 const char* start = "我是东北大学TDT创新团队的天宝机器人，看我很可爱吧。我可以模仿你的动作哦！在未来我是你的家庭小帮手，也是你的好伙伴。我能够帮助照顾老人，提供行动上的辅助和情感上的交流。";//1-4
	makeTextToWav(start,fileName);
	playWav();
	ros::init(argc,argv,"xf_tts_node");
	ros::NodeHandle nd;
	ros::Subscriber sub=nd.subscribe("/voice/xf_tts_topics",3,topicCallBack);
	ros::spin();
	return 0;
}
