#include<ros/ros.h>
#include<std_msgs/Int16.h>
void callback(const std_msgs::Int16::ConstPtr& msg)
{
ROS_INFO("the number is %d\n",msg->data);
}

int main(int argc,char **argv)
{
ros::init(argc,argv,"control_node");
ros::NodeHandle n;
ros::Subscriber sub=n.subscribe("/voice/control_topic",3,callback);
ros::spin();
return 0;
}

