/*
* 语音听写(iFly Auto Transform)技术能够实时地将语音转换成对应的文字。
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <ros/ros.h>
#include "qisr.h"
#include "msp_cmn.h"
#include "msp_errors.h"
#include "speech_recognizer.h"
#include<jsoncpp/json/json.h>
#include<std_msgs/String.h>
#include<std_msgs/Int16.h>
#include<sstream>
using namespace std;
string results ="";//用来传递json格式字符串的标志符
//string send="";//用来发送给语音模块的标志符
bool asrflag =false;
bool recflag =true;
#define FRAME_LEN	640 
#define	BUFFER_SIZE	4096
#define SAMPLE_RATE_16K     (16000)
#define SAMPLE_RATE_8K      (8000)
#define MAX_GRAMMARID_LEN   (32)
#define MAX_PARAMS_LEN      (1024)//与不是常数没啥区别

const char * ASR_RES_PATH        = "fo|/home/lmlm/catkin_ws/src/voice_system/bin/msc/res/asr/common.jet"; //离线语法识别资源路径
const char * GRM_BUILD_PATH      = "/home/lmlm/catkin_ws/src/voice_system/bin/msc/res/asr/res/asr/GrmBuilld"; //构建离线语法识别网络生成数据保存路径
const char * GRM_FILE            = "/home/lmlm/catkin_ws/src/voice_system/bin/call.bnf"; //构建离线识别语法网络所用的语法文件
const char * LEX_NAME            = "contact"; //更新离线识别语法的contact槽（语法文件为此示例中使用的call.bnf）

typedef struct _UserData {
	int     build_fini; //标识语法构建是否完成
	int     update_fini; //标识更新词典是否完成
	int     errcode; //记录语法构建或更新词典回调错误码
	char    grammar_id[MAX_GRAMMARID_LEN]; //保存语法构建返回的语法ID
}UserData;


const char *get_audio_file(void); //选择进行离线语法识别的语音文件
int build_grammar(UserData *udata); //构建离线识别语法网络
int update_lexicon(UserData *udata); //更新离线识别语法词典
int run_asr(UserData *udata); //进行离线语法识别


int build_grm_cb(int ecode, const char *info, void *udata)//构建语法id回调窗口
{
	UserData *grm_data = (UserData *)udata;

	if (NULL != grm_data) {
		grm_data->build_fini = 1;
		grm_data->errcode = ecode;
	}

	if (MSP_SUCCESS == ecode && NULL != info) {
		printf("构建语法成功！ 语法ID:%s\n", info);
		if (NULL != grm_data)
			snprintf(grm_data->grammar_id, MAX_GRAMMARID_LEN - 1, info);
	}
	else
		printf("构建语法失败！%d\n", ecode);

	return 0;
}

int build_grammar(UserData *udata)//构建语法
{
	FILE *grm_file                           = NULL;
	char *grm_content                        = NULL;
	unsigned int grm_cnt_len                 = 0;
	char grm_build_params[MAX_PARAMS_LEN]    = {NULL};
	int ret                                  = 0;

	grm_file = fopen(GRM_FILE, "rb");//GRM_FILE文件路径	
	if(NULL == grm_file) {
		printf("打开\"%s\"文件失败！[%s]\n", GRM_FILE, strerror(errno));
		return -1; 
	}//文件打开错误

	fseek(grm_file, 0, SEEK_END);
	grm_cnt_len = ftell(grm_file);//当前文件指针相对于文件首部的偏移量
	fseek(grm_file, 0, SEEK_SET);

	grm_content = (char *)malloc(grm_cnt_len + 1);
	if (NULL == grm_content)
	{
		printf("内存分配失败!\n");
		fclose(grm_file);
		grm_file = NULL;
		return -1;
	}
	fread((void*)grm_content, 1, grm_cnt_len, grm_file);//语法内容
	grm_content[grm_cnt_len] = '\0';
	fclose(grm_file);
	//printf("%s\n",grm_content);//语法文件读入12.31
	grm_file = NULL;

	snprintf(grm_build_params, MAX_PARAMS_LEN - 1, 
		"engine_type = local, \
		asr_res_path = %s, sample_rate = %d, \
		grm_build_path = %s, ",
		ASR_RES_PATH,
		SAMPLE_RATE_16K,
		GRM_BUILD_PATH
		);
printf("%d\n",grm_cnt_len);
printf("%s\n",grm_build_params);
	ret = QISRBuildGrammar("bnf", grm_content, grm_cnt_len, grm_build_params, build_grm_cb, udata);//构建语法，build_grm_cb构建语法回调窗口

	free(grm_content);
	grm_content = NULL;

	return ret;
}

int update_lex_cb(int ecode, const char *info, void *udata)
{
	UserData *lex_data = (UserData *)udata;

	if (NULL != lex_data) {
		lex_data->update_fini = 1;
		lex_data->errcode = ecode;
	}

	if (MSP_SUCCESS == ecode)
		printf("更新词典成功！\n");
	else
		printf("更新词典失败！%d\n", ecode);

	return 0;
}

int update_lexicon(UserData *udata)
{
	const char *lex_content                   = "后退\n前进";
	unsigned int lex_cnt_len                  = strlen(lex_content);
	char update_lex_params[MAX_PARAMS_LEN]    = {NULL}; 

	snprintf(update_lex_params, MAX_PARAMS_LEN - 1, 
		"engine_type = local, text_encoding = UTF-8, \
		asr_res_path = %s, sample_rate = %d, \
		grm_build_path = %s, grammar_list = %s, ",
		ASR_RES_PATH,//离线语法词典路径
		SAMPLE_RATE_16K,
		GRM_BUILD_PATH,
		udata->grammar_id);
	return QISRUpdateLexicon(LEX_NAME, lex_content, lex_cnt_len, update_lex_params, update_lex_cb, udata);//更新离线语法，词典名称，本地语法词典内容，词典内容长度，参数设定，更新词典回调借口，用户数据
}

int parseJsonResponse(string input)
{
	string out;
	int in;
	Json::Value root;
	Json::Reader reader;
	bool parsingSuccessful =reader.parse(input,root);
	if(!parsingSuccessful)
	{
	cout<<"!!!Failed to parse the response data"<<endl;
	return 1;
	}
	const Json::Value num=root["ws"];//导入ws类	
	for (unsigned int i = 0; i < num.size(); i++)  
        {
		if (!num[i].isMember("cw"))   
                continue;  
	 //out = num[i]["slot"].asString();//调用二级目录
	const Json::Value num1=num[i]["cw"];//导入num类
	for (unsigned int j = 0; j < num1.size(); j++)  
        {
		if (!num1[j].isMember("id"))   
                continue;
	//printf("%d\n",j);
	in=num1[j]["id"].asInt();
	cout<<in<<endl;
	
	break;
}
	/*for (unsigned int k = 0; k < num1.size(); k++)  
        {
		if (!num1[k].isMember("w"))   
                continue;
	//printf("%d\n",j);
	//send=num1[k]["w"].asString();
	//cout<<in<<endl;
	asrflag = true;
	break;

}*/
break;
	//std::string out = code[i]["id"].asString();  
          //  cout << out<<"继续"<<endl;  
      
	}
//}

	return in;
}


static void show_result(char *string, char is_over)//显示结果
{
	printf("\rResult: [ %s ]", string);
	results=string;
	if(is_over)
		putchar('\n');
asrflag = true;
}

static char *g_result = NULL;
static unsigned int g_buffersize = BUFFER_SIZE;

void on_result(const char *result, char is_last)
{
	if (result) {
		size_t left = g_buffersize - 1 - strlen(g_result);
		size_t size = strlen(result);
		if (left < size) {
			g_result = (char*)realloc(g_result, g_buffersize + BUFFER_SIZE);
			if (g_result)
				g_buffersize += BUFFER_SIZE;
			else {
				printf("mem alloc failed\n");
				return;
			}
		}
		strncat(g_result, result, size);//拼接字符串,g_result,result数据内容一致
	
		show_result(g_result, is_last);//显示输出
	}
}
void on_speech_begin()
{
	if (g_result)
	{
		free(g_result);
	}
	g_result = (char*)malloc(BUFFER_SIZE);
	g_buffersize = BUFFER_SIZE;
	memset(g_result, 0, g_buffersize);

	printf("Start Listening...\n");
}
void on_speech_end(int reason)
{
	if (reason == END_REASON_VAD_DETECT)
{
		printf("\nSpeaking done \n");
		recflag =false;
}
	else
		printf("\nRecognizer error %d\n", reason);
}

/* demo recognize the audio from microphone */
static void demo_mic(const char* session_begin_params)
{
	int errcode;
	int i = 0;

	struct speech_rec iat;

	struct speech_rec_notifier recnotifier = {
		on_result,
		on_speech_begin,
		on_speech_end
	};

	errcode = sr_init(&iat, session_begin_params, SR_MIC, &recnotifier);
	if (errcode) {
		printf("speech recognizer init failed\n");
		return;
	}
	errcode = sr_start_listening(&iat);
	if (errcode) {
		printf("start listen failed %d\n", errcode);
	}
	/* demo 15 seconds recording */
	while(recflag)
		sleep(1);
	errcode = sr_stop_listening(&iat);
	if (errcode) {
		printf("stop listening failed %d\n", errcode);
	}

	sr_uninit(&iat);
}

int run_asr(UserData *udata)//识别代码
{
	char asr_params[MAX_PARAMS_LEN]    = {NULL};
	const char *rec_rslt               = NULL;
	const char *session_id             = NULL;
	const char *asr_audiof             = NULL;
	FILE *f_pcm                        = NULL;
	char *pcm_data                     = NULL;
	long pcm_count                     = 0;
	long pcm_size                      = 0;
	int last_audio                     = 0;

	int aud_stat                       = MSP_AUDIO_SAMPLE_CONTINUE;
	int ep_status                      = MSP_EP_LOOKING_FOR_SPEECH;
	int rec_status                     = MSP_REC_STATUS_INCOMPLETE;
	int rss_status                     = MSP_REC_STATUS_INCOMPLETE;
	int errcode                        = -1;
	int aud_src                        = 0;
	//离线语法识别参数设置
	snprintf(asr_params, MAX_PARAMS_LEN - 1, 
		"engine_type = local, \
		asr_res_path = %s, sample_rate = %d, \
		grm_build_path = %s, local_grammar = %s, \
		result_type = json, result_encoding = UTF-8, ",
		ASR_RES_PATH,
		SAMPLE_RATE_16K,
		GRM_BUILD_PATH,
		udata->grammar_id
		);
	printf("音频数据在哪? \n0: 从文件读入\n1:从MIC说话\n");
	scanf("%d", &aud_src);
	if(aud_src != 0) {
		demo_mic(asr_params);
	} 
	return 0;
}
int maketext()
{
	const char *login_config    = "appid = 57331875"; //登录参数
	UserData asr_data; 
	int ret                     = 0 ;
	char c;

	ret = MSPLogin(NULL, NULL, login_config); //第一个参数为用户名，第二个参数为密码，传NULL即可，第三个参数是登录参数
	if (MSP_SUCCESS != ret) {
		printf("登录失败：%d\n", ret);
		goto exit;
	}

	memset(&asr_data, 0, sizeof(UserData));
	printf("构建离线识别语法网络...\n");
	ret = build_grammar(&asr_data);  //第一次使用某语法进行识别，需要先构建语法网络，获取语法ID，之后使用此语法进行识别，无需再次构建
	if (MSP_SUCCESS != ret) {
		printf("构建语法调用失败！\n");
		goto exit;
	}
	while (1 != asr_data.build_fini)
		usleep(300 * 1000);
	if (MSP_SUCCESS != asr_data.errcode)
		goto exit;
	printf("离线识别语法网络构建完成，开始识别...\n");	
	ret = run_asr(&asr_data);
	if (MSP_SUCCESS != ret) {
		printf("离线语法识别出错: %d \n", ret);
		goto exit;
	}

	/*printf("更新离线语法词典...\n");1.1取消更新语法词典
	ret = update_lexicon(&asr_data);  //当语法词典槽中的词条需要更新时，调用QISRUpdateLexicon接口完成更新
	if (MSP_SUCCESS != ret) {
		printf("更新词典调用失败！\n");
		goto exit;
	}
	while (1 != asr_data.update_fini)
		usleep(300 * 1000);
	if (MSP_SUCCESS != asr_data.errcode)
		goto exit;
	printf("更新离线语法词典完成，开始识别...\n");
	ret = run_asr(&asr_data);
	if (MSP_SUCCESS != ret) {
		printf("离线语法识别出错: %d \n", ret);
		goto exit;
	}*/

exit:
	MSPLogout();
	//printf("请按任意键退出...\n");
	//getchar();
return 0;
}

int main(int argc, char* argv[])
{
	int c;
	ros::init(argc,argv,"shibie");
	ros::NodeHandle n;
	ros::Publisher pub=n.advertise<std_msgs::Int16>("/voice/control_topic",3);
	//ros::Publisher pubse=n.advertise<std_msgs::String>("/voice/xf_tts_topic",3);//1.1
	ros::Rate loop_rate(10);
	c=maketext();
	while(ros::ok())
	{
		if(asrflag)
		{
			std_msgs::Int16 msg;
			//std_msgs::String msgse;//必须大写
			c=parseJsonResponse(results);
			msg.data =c;
			//msgse.data=send;
			pub.publish(msg);
			//pubse.publish(msgse);
			asrflag = false;
			recflag = true;
		}
		loop_rate.sleep();
		ros::spinOnce();
	}

	return 0;
}
