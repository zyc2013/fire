#!/usr/bin/env bash
BASE=$1
echo "export RIKIBASE=$BASE" >> ~/.bashrc
source ~/.bashrc
