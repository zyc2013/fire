rosrun map_server map_saver -f house
