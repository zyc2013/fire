# Overview #

ros_arduino_msgs are ROS messages that have been lightened. 