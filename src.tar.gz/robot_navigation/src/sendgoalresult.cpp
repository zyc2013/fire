
#include <sstream>
#include "ros/ros.h"
#include "std_msgs/String.h"

int main(int argc, char **argv)
{
  ros::init(argc, argv, "sendgoalresult");
  ros::NodeHandle n;
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("result", 10);

    std_msgs::String msgs,msgf;
    std::stringstream succeeded,failed;
    succeeded << "You have arrived to the goal position. " << count;
    failed << "You have arrived to the goal position. " << count;
    msgs.data = succeeded.str();
    msgf.data = failed.str();



  ac.waitForResult();
  if(ac.detState() == actionlib::SimpleClientgoalState::SUCCEEDED){
    ROS_INFO("%s", msgs.data.c_str());
    chatter_pub.publish(msgs);
  }
  else {
    ROS_INFO("%s", msgf.data.c_str());
    chatter_pub.publish(msgf);
  }

  return 0;
}
