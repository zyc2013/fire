#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <tf/transform_broadcaster.h>
#include <sstream>
#include "std_msgs/String.h"

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>MoveBaseClient;

int main(int argc, char** argv)
{
    ros::init(argc, argv, "navigation_goals");

    ros::NodeHandle n;
    ros::Publisher sendgoalresult_pub = n.advertise<std_msgs::String>("result", 10);

    ros::Rate loop_rate(1);
    
    while(ros::ok())
   {
    std_msgs::String msgs,msgf;
    std::stringstream succeeded,failed;
    succeeded << "a" ;
    failed << "b" ;
    msgs.data = succeeded.str();
    msgf.data = failed.str();
    sendgoalresult_pub.publish(msgs);
    ROS_INFO("%s",msgs.data.c_str());
    ros::spinOnce();
    loop_rate.sleep();
   }
 
   
    return 0;
}


